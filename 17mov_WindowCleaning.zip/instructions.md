Ours multiplayer jobs are basically drag & drop.

If you're running a custom framework, remember to adjust ur clothing system on /client/functions.lua, and ur payment system on /server/functions.lua

If you have any problems, ask for help on our discord:
https://discord.gg/dWUmBQ6KuJ